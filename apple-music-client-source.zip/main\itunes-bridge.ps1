param($ParentProcessId)

$script:iTunes = $null
$script:lastTrackId = $null
$script:lastState = $null
$script:running = $true

function Get-ITunes {
    if (-not $script:iTunes) {
        try {
            $script:iTunes = New-Object -ComObject "iTunes.Application" -ErrorAction Stop
        } catch {
            return $null
        }
    }
    return $script:iTunes
}

function Get-TrackInfo {
    param($track)
    if (-not $track) { return $null }
    $artworkCount = 0
    try { $artworkCount = $track.Artwork.Count } catch {}
    return @{
        id = try { $track.TrackID } catch { 0 }
        name = try { $track.Name } catch { "Unknown" }
        artist = try { $track.Artist } catch { "Unknown" }
        album = try { $track.Album } catch { "Unknown" }
        albumArtist = try { $track.AlbumArtist } catch { "" }
        duration = try { $track.Duration } catch { 0 }
        trackNumber = try { $track.TrackNumber } catch { 0 }
        year = try { $track.Year } catch { 0 }
        genre = try { $track.Genre } catch { "" }
        artworkCount = $artworkCount
        rating = try { $track.Rating } catch { 0 }
    }
}

function Get-State {
    $it = Get-ITunes
    if (-not $it) { return "stopped" }
    try {
        $s = $it.PlayerState
        if ($s -eq 1) { return "playing" }
        if ($s -eq 2) { return "paused" }
    } catch {}
    return "stopped"
}

function Get-CurrentTrack {
    $it = Get-ITunes
    if (-not $it) { return $null }
    try {
        return Get-TrackInfo $it.CurrentTrack
    } catch { return $null }
}

function Get-Volume {
    $it = Get-ITunes
    if (-not $it) { return 50 }
    try { return $it.SoundVolume } catch { return 50 }
}

function Get-Playlists {
    $it = Get-ITunes
    if (-not $it) { return @() }
    try {
        $playlists = $it.LibrarySource.Playlists
        $count = $playlists.Count
        $result = @()
        for ($i = 1; $i -le $count; $i++) {
            $pl = $playlists.Item($i)
            $result += @{
                name = try { $pl.Name } catch { "" }
                playlistId = try { $pl.PlaylistID } catch { 0 }
                trackCount = try { $pl.Tracks.Count } catch { 0 }
                duration = try { $pl.Duration } catch { 0 }
            }
        }
        return $result
    } catch { return @() }
}

function Get-Position {
    $it = Get-ITunes
    if (-not $it) { return 0 }
    try { return $it.PlayerPosition } catch { return 0 }
}

function Write-JsonMessage {
    param($Type, $Data)
    $msg = @{ type = $Type; data = $Data }
    try {
        $json = $msg | ConvertTo-Json -Compress -Depth 10
        $json = $json -replace "`n", " " -replace "`r", " "
        Write-Host "$json"
    } catch {
        Write-Host '{"type":"error","data":"Serialize error"}'
    }
}

function Handle-Command($cmd) {
    $action = $cmd.action
    switch ($action) {
        "connect" {
            $it = Get-ITunes
            if ($it -and $it) {
                Write-JsonMessage "connected" $true
            } else {
                Write-JsonMessage "connected" $false
            }
        }
        "get-player-state" { Write-JsonMessage "result" (Get-State) }
        "get-volume" { Write-JsonMessage "result" (Get-Volume) }
        "get-current-track" { Write-JsonMessage "result" (Get-CurrentTrack) }
        "get-playlists" { Write-JsonMessage "result" (Get-Playlists) }
        "get-player-position" { Write-JsonMessage "result" (Get-Position) }
        "play-pause" { try { (Get-ITunes).PlayPause() } catch {} }
        "play" { try { (Get-ITunes).Play() } catch {} }
        "pause" { try { (Get-ITunes).Pause() } catch {} }
        "next-track" { try { (Get-ITunes).NextTrack() } catch {} }
        "previous-track" { try { (Get-ITunes).PreviousTrack() } catch {} }
        "set-volume" { try { (Get-ITunes).SoundVolume = [int]$cmd.value } catch {} }
        "set-player-position" { try { (Get-ITunes).PlayerPosition = [double]$cmd.value } catch {} }
        "play-playlist" {
            try {
                $it = Get-ITunes
                $name = $cmd.value
                $playlists = $it.LibrarySource.Playlists
                for ($i = 1; $i -le $playlists.Count; $i++) {
                    $pl = $playlists.Item($i)
                    if ($pl.Name -eq $name) {
                        if ($pl.Tracks.Count -gt 0) {
                            $pl.Tracks.Item(1).Play()
                        }
                        break
                    }
                }
            } catch {}
        }
        "quit" { $script:running = $false; exit 0 }
    }
}

$reader = [System.Console]::In
$parentPid = [int]$ParentProcessId

Write-JsonMessage "ready" $true

while ($script:running) {
    $track = Get-CurrentTrack
    $state = Get-State

    $trackId = if ($track) { $track.id } else { -1 }
    if ($trackId -ne $script:lastTrackId) {
        $script:lastTrackId = $trackId
        Write-JsonMessage "track-changed" $track
    }
    if ($state -ne $script:lastState) {
        $script:lastState = $state
        Write-JsonMessage "state-changed" $state
    }

    if ($reader.KeyAvailable) {
        $line = try { $reader.ReadLine() } catch { $null }
        if ($line) {
            try {
                $cmd = $line | ConvertFrom-Json
                Handle-Command $cmd
            } catch {
                Write-JsonMessage "error" "Invalid command"
            }
        }
    }

    try {
        $parent = [System.Diagnostics.Process]::GetProcessById($parentPid)
        if (-not $parent) { exit 0 }
    } catch { exit 0 }

    Start-Sleep -Milliseconds 500
}
