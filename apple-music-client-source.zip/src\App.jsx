import React, { useState, useEffect, useCallback } from 'react';
import './App.css';

const formatTime = (sec) => {
  if (!sec || isNaN(sec)) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
};

function TitleBar() {
  const handleMinimize = () => window.appleMusic?.minimize?.();
  const handleMaximize = () => window.appleMusic?.maximize?.();
  const handleClose = () => window.appleMusic?.close?.();

  return (
    <div className="titlebar">
      <div className="titlebar-drag">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="1.5" fill="none" />
          <path d="M5 8h6M8 5v6" stroke="currentColor" strokeWidth="1.2" />
        </svg>
        <span>Apple Music</span>
      </div>
      <div className="titlebar-controls">
        <button className="tb-btn" onClick={handleMinimize} title="Minimize">
          <svg width="12" height="12" viewBox="0 0 12 12"><rect y="5" width="12" height="2" fill="currentColor"/></svg>
        </button>
        <button className="tb-btn" onClick={handleMaximize} title="Maximize">
          <svg width="12" height="12" viewBox="0 0 12 12"><rect x="1" y="1" width="10" height="10" rx="1" fill="none" stroke="currentColor" strokeWidth="1.5"/></svg>
        </button>
        <button className="tb-btn tb-close" onClick={handleClose} title="Close">
          <svg width="12" height="12" viewBox="0 0 12 12"><path d="M2 2l8 8M10 2l-8 8" stroke="currentColor" strokeWidth="1.5"/></svg>
        </button>
      </div>
    </div>
  );
}

function NowPlaying({ track, state, position, progress }) {
  if (!track) {
    return (
      <div className="nowplaying empty">
        <div className="album-art-placeholder">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.4">
            <circle cx="12" cy="12" r="10"/>
            <path d="M9 18V6l8 4-8 4"/>
          </svg>
        </div>
        <div className="no-track">No track playing</div>
        <div className="sub-text">Open Apple Music and play something</div>
      </div>
    );
  }

  return (
    <div className="nowplaying">
      <div className="album-art">
        <div className="album-art-inner">
          {track.artworkCount > 0 ? (
            <span>🎵</span>
          ) : (
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.6">
              <circle cx="12" cy="12" r="10"/>
              <path d="M9 18V6l8 4-8 4"/>
            </svg>
          )}
        </div>
      </div>
      <div className="track-info">
        <div className="track-name" title={track.name}>{track.name}</div>
        <div className="track-artist" title={track.artist}>{track.artist}</div>
        <div className="track-album" title={track.album}>{track.album}</div>
      </div>
      <div className="progress-bar">
        <div className="progress-time">{formatTime(position)}</div>
        <div className="progress-track">
          <div className="progress-fill" style={{ width: `${progress}%` }} />
        </div>
        <div className="progress-time">{formatTime(track.duration)}</div>
      </div>
    </div>
  );
}

function PlaybackControls({ state, volume, onPlayPause, onNext, onPrev, onVolumeChange }) {
  return (
    <div className="playback-controls">
      <button className="ctrl-btn" onClick={onPrev} title="Previous">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/>
        </svg>
      </button>
      <button className="ctrl-btn ctrl-play" onClick={onPlayPause} title={state === 'playing' ? 'Pause' : 'Play'}>
        {state === 'playing' ? (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
            <rect x="6" y="4" width="4" height="16" rx="1"/>
            <rect x="14" y="4" width="4" height="16" rx="1"/>
          </svg>
        ) : (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
            <path d="M8 5v14l11-7z"/>
          </svg>
        )}
      </button>
      <button className="ctrl-btn" onClick={onNext} title="Next">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M16 6h2v12h-2zm-3.5 6l-8.5 6V6z"/>
        </svg>
      </button>
      <div className="volume-control">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" opacity="0.6">
          <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 8.5v7a4.47 4.47 0 002.5-3.5z"/>
        </svg>
        <input
          type="range"
          className="volume-slider"
          min="0" max="100"
          value={volume}
          onChange={(e) => onVolumeChange(Number(e.target.value))}
        />
      </div>
    </div>
  );
}

function PlaylistView({ playlists, onPlayPlaylist }) {
  const [expanded, setExpanded] = useState({});

  const toggle = (name) => {
    setExpanded((prev) => ({ ...prev, [name]: !prev[name] }));
  };

  return (
    <div className="playlist-view">
      <div className="section-title">Playlists</div>
      <div className="playlist-list">
        {playlists.length === 0 && (
          <div className="empty-playlists">No playlists found</div>
        )}
        {playlists.map((pl) => (
          <div key={pl.playlistId} className="playlist-item" onClick={() => onPlayPlaylist(pl.name)}>
            <div className="pl-icon">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" opacity="0.6">
                <path d="M12 3v10.55A4 4 0 1014 17V7h4V3h-6z"/>
              </svg>
            </div>
            <div className="pl-info">
              <div className="pl-name">{pl.name}</div>
              <div className="pl-count">{pl.trackCount} tracks</div>
            </div>
            <div className="pl-duration">{formatTime(pl.duration)}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function App() {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState(null);
  const [track, setTrack] = useState(null);
  const [state, setState] = useState('stopped');
  const [volume, setVolume] = useState(50);
  const [position, setPosition] = useState(0);
  const [playlists, setPlaylists] = useState([]);
  const [view, setView] = useState('nowplaying');
  const [progress, setProgress] = useState(0);

  const handleConnect = useCallback(async () => {
    const api = window.appleMusic;
    if (!api) {
      setError('Preload API not available. Restart the app.');
      return;
    }
    setConnecting(true);
    setError(null);
    try {
      const ok = await api.connect();
      if (ok) {
        const [t, s, v, p, pl] = await Promise.all([
          api.getCurrentTrack(),
          api.getPlayerState(),
          api.getVolume(),
          api.getPlayerPosition(),
          api.getPlaylists(),
        ]);
        setTrack(t);
        setState(s);
        setVolume(v);
        setPosition(p);
        setPlaylists(pl);
        setProgress(t?.duration ? (p / t.duration) * 100 : 0);
      } else {
        setError('Could not connect to Apple Music. Make sure it is installed and running.');
      }
    } catch (e) {
      setError('Connection failed: ' + e.message);
    } finally {
      setConnecting(false);
    }
  }, []);

  useEffect(() => {
    const api = window.appleMusic;
    if (!api) {
      setError('Preload API not loaded. The app may be corrupted.');
      return;
    }

    const posInterval = setInterval(async () => {
      if (!connected) return;
      const pos = await api.getPlayerPosition();
      setPosition(pos);
      setTrack((prev) => {
        if (prev?.duration) {
          setProgress((pos / prev.duration) * 100);
        }
        return prev;
      });
    }, 500);

    api.onTrackChange((t) => {
      setTrack(t);
      setPosition(0);
      setProgress(0);
    });

    api.onStateChange((s) => setState(s));

    api.onConnectionChange((c) => {
      setConnected(c);
      if (c) setError(null);
    });

    return () => {
      clearInterval(posInterval);
    };
  }, [connected]);

  const handlePlayPause = () => window.appleMusic?.playPause();
  const handleNext = () => window.appleMusic?.nextTrack();
  const handlePrev = () => window.appleMusic?.previousTrack();
  const handleVolumeChange = (vol) => {
    setVolume(vol);
    window.appleMusic?.setVolume(vol);
  };
  const handlePlayPlaylist = async (name) => {
    await window.appleMusic?.playPlaylist(name);
    setView('nowplaying');
  };

  return (
    <div className="app">
      <TitleBar />

      {!connected && (
        <div className="connect-screen">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.5">
            <circle cx="12" cy="12" r="10"/>
            <path d="M9 18V6l8 4-8 4"/>
          </svg>
          <h2>Apple Music Client</h2>
          <p>Connect to Apple Music (or iTunes) to control playback.</p>
          {error && <div className="error-msg">{error}</div>}
          <button className="connect-btn" onClick={handleConnect} disabled={connecting}>
            {connecting ? 'Connecting...' : 'Connect to Apple Music'}
          </button>
        </div>
      )}

      {connected && (
        <>
          <div className="nav-bar">
            <button className={`nav-btn ${view === 'nowplaying' ? 'active' : ''}`} onClick={() => setView('nowplaying')}>Now Playing</button>
            <button className={`nav-btn ${view === 'playlists' ? 'active' : ''}`} onClick={() => setView('playlists')}>Playlists</button>
          </div>

          <div className="content">
            {view === 'nowplaying' && (
              <>
                <NowPlaying track={track} state={state} position={position} progress={progress} />
                <PlaybackControls
                  state={state}
                  volume={volume}
                  onPlayPause={handlePlayPause}
                  onNext={handleNext}
                  onPrev={handlePrev}
                  onVolumeChange={handleVolumeChange}
                />
              </>
            )}
            {view === 'playlists' && (
              <PlaylistView playlists={playlists} onPlayPlaylist={handlePlayPlaylist} />
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default App;
