const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('appleMusic', {
  onTrackChange: (callback) =>
    ipcRenderer.on('track-changed', (_event, track) => callback(track)),
  onStateChange: (callback) =>
    ipcRenderer.on('state-changed', (_event, state) => callback(state)),
  onVolumeChange: (callback) =>
    ipcRenderer.on('volume-changed', (_event, vol) => callback(vol)),
  onConnectionChange: (callback) =>
    ipcRenderer.on('connection-changed', (_event, connected) => callback(connected)),

  connect: () => ipcRenderer.invoke('connect'),
  disconnect: () => ipcRenderer.invoke('disconnect'),
  getPlayerState: () => ipcRenderer.invoke('get-player-state'),
  getVolume: () => ipcRenderer.invoke('get-volume'),
  getCurrentTrack: () => ipcRenderer.invoke('get-current-track'),
  getPlaylists: () => ipcRenderer.invoke('get-playlists'),

  playPause: () => ipcRenderer.invoke('play-pause'),
  play: () => ipcRenderer.invoke('play'),
  pause: () => ipcRenderer.invoke('pause'),
  nextTrack: () => ipcRenderer.invoke('next-track'),
  previousTrack: () => ipcRenderer.invoke('previous-track'),
  setVolume: (vol) => ipcRenderer.invoke('set-volume', vol),
  playPlaylist: (name) => ipcRenderer.invoke('play-playlist', name),
  getPlayerPosition: () => ipcRenderer.invoke('get-player-position'),
  setPlayerPosition: (sec) => ipcRenderer.invoke('set-player-position', sec),

  minimize: () => ipcRenderer.invoke('minimize'),
  maximize: () => ipcRenderer.invoke('maximize'),
  close: () => ipcRenderer.invoke('close'),
});
