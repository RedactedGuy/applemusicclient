const { spawn } = require('child_process');
const path = require('path');
const readline = require('readline');

let psProcess = null;
let rl = null;
let pendingResolve = null;
let pendingTimeout = null;

const listeners = new Map();

function notify(event, data) {
  const cbs = listeners.get(event) || [];
  cbs.forEach((fn) => fn(data));
}

function on(event, callback) {
  if (!listeners.has(event)) listeners.set(event, []);
  listeners.get(event).push(callback);
}

function off(event, callback) {
  const cbs = listeners.get(event);
  if (cbs) {
    const idx = cbs.indexOf(callback);
    if (idx !== -1) cbs.splice(idx, 1);
  }
}

function handleMessage(msg) {
  if (!msg || !msg.type) return;
  switch (msg.type) {
    case 'connected':
      notify('connected', msg.data);
      break;
    case 'track-changed':
      notify('track-changed', msg.data);
      break;
    case 'state-changed':
      notify('state-changed', msg.data);
      break;
    case 'result':
      if (pendingResolve) {
        pendingResolve(msg.data);
        pendingResolve = null;
        if (pendingTimeout) {
          clearTimeout(pendingTimeout);
          pendingTimeout = null;
        }
      }
      break;
    case 'ready':
      notify('ready', true);
      break;
    case 'error':
      break;
  }
}

function connect() {
  return new Promise((resolve) => {
    if (psProcess) {
      disconnect();
    }

    const scriptPath = path.join(__dirname, 'itunes-bridge.ps1');
    const ppid = process.pid;

    psProcess = spawn('powershell.exe', [
      '-NoProfile',
      '-NonInteractive',
      '-ExecutionPolicy', 'Bypass',
      '-File', scriptPath,
      ppid.toString(),
    ], {
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    });

    let buffer = '';
    psProcess.stdout.on('data', (chunk) => {
      buffer += chunk.toString('utf8');
      const lines = buffer.split('\n');
      buffer = lines.pop();
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed) continue;
        try {
          const msg = JSON.parse(trimmed);
          handleMessage(msg);
        } catch {
          // skip partial/invalid lines
        }
      }
    });

    psProcess.stderr.on('data', (chunk) => {
      // ignore stderr
    });

    psProcess.on('exit', () => {
      psProcess = null;
      rl = null;
      if (pendingResolve) {
        pendingResolve(null);
        pendingResolve = null;
      }
      notify('disconnected', true);
    });

    psProcess.on('error', () => {
      psProcess = null;
      rl = null;
      resolve(false);
    });

    const readyHandler = () => {
      off('ready', readyHandler);
      resolve(true);
    };
    on('ready', readyHandler);

    setTimeout(() => {
      off('ready', readyHandler);
      if (!psProcess) {
        resolve(false);
      }
    }, 10000);
  });
}

function disconnect() {
  if (psProcess) {
    sendCommand('quit');
    psProcess.kill();
    psProcess = null;
    rl = null;
  }
  if (pendingTimeout) {
    clearTimeout(pendingTimeout);
    pendingTimeout = null;
  }
  pendingResolve = null;
}

function isConnected() {
  return psProcess !== null;
}

function sendCommand(action, value) {
  if (!psProcess || !psProcess.stdin.writable) return;
  const cmd = { action };
  if (value !== undefined) cmd.value = value;
  psProcess.stdin.write(JSON.stringify(cmd) + '\n');
}

function sendCommandWithResult(action, value) {
  return new Promise((resolve) => {
    if (!psProcess) return resolve(null);
    pendingResolve = resolve;
    sendCommand(action, value);
    pendingTimeout = setTimeout(() => {
      if (pendingResolve) {
        pendingResolve(null);
        pendingResolve = null;
      }
    }, 5000);
  });
}

function getPlayerState() {
  return sendCommandWithResult('get-player-state');
}

function getVolume() {
  return sendCommandWithResult('get-volume');
}

function setVolume(vol) {
  sendCommand('set-volume', Math.max(0, Math.min(100, vol)));
}

function getCurrentTrack() {
  return sendCommandWithResult('get-current-track');
}

function playPause() {
  sendCommand('play-pause');
}

function play() {
  sendCommand('play');
}

function pause() {
  sendCommand('pause');
}

function nextTrack() {
  sendCommand('next-track');
}

function previousTrack() {
  sendCommand('previous-track');
}

function getPlaylists() {
  return sendCommandWithResult('get-playlists');
}

function playPlaylist(name) {
  sendCommand('play-playlist', name);
}

function getPlayerPosition() {
  return sendCommandWithResult('get-player-position');
}

function setPlayerPosition(seconds) {
  sendCommand('set-player-position', seconds);
}

function startPolling() {
}

function stopPolling() {
}

module.exports = {
  on, off, connect, disconnect, isConnected,
  getPlayerState, getVolume, setVolume,
  getCurrentTrack, playPause, play, pause,
  nextTrack, previousTrack, getPlaylists, playPlaylist,
  getPlayerPosition, setPlayerPosition, startPolling, stopPolling,
};
