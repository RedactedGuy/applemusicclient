const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const bridge = require('./itunes-bridge.js');

let mainWindow = null;
let connected = false;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 400,
    height: 600,
    minWidth: 340,
    minHeight: 500,
    frame: false,
    transparent: false,
    backgroundColor: '#1c1c1e',
    resizable: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, '..', 'renderer-dist', 'index.html'));

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

function setupIPC() {
  ipcMain.handle('connect', async () => {
    connected = await bridge.connect();
    if (mainWindow) {
      mainWindow.webContents.send('connection-changed', connected);
    }
    return connected;
  });

  ipcMain.handle('disconnect', () => {
    bridge.disconnect();
    connected = false;
    if (mainWindow) {
      mainWindow.webContents.send('connection-changed', false);
    }
  });

  ipcMain.handle('get-player-state', () => bridge.getPlayerState());
  ipcMain.handle('get-volume', () => bridge.getVolume());
  ipcMain.handle('get-current-track', () => bridge.getCurrentTrack());
  ipcMain.handle('get-playlists', () => bridge.getPlaylists());
  ipcMain.handle('play-pause', () => bridge.playPause());
  ipcMain.handle('play', () => bridge.play());
  ipcMain.handle('pause', () => bridge.pause());
  ipcMain.handle('next-track', () => bridge.nextTrack());
  ipcMain.handle('previous-track', () => bridge.previousTrack());
  ipcMain.handle('set-volume', (_e, vol) => bridge.setVolume(vol));
  ipcMain.handle('play-playlist', (_e, name) => bridge.playPlaylist(name));
  ipcMain.handle('get-player-position', () => bridge.getPlayerPosition());
  ipcMain.handle('set-player-position', (_e, sec) => bridge.setPlayerPosition(sec));

  ipcMain.handle('minimize', () => mainWindow?.minimize());
  ipcMain.handle('maximize', () => {
    if (mainWindow?.isMaximized()) {
      mainWindow.unmaximize();
    } else {
      mainWindow?.maximize();
    }
  });
  ipcMain.handle('close', () => mainWindow?.close());

  bridge.on('track-changed', (track) => {
    mainWindow?.webContents.send('track-changed', track);
  });

  bridge.on('state-changed', (state) => {
    mainWindow?.webContents.send('state-changed', state);
  });

  bridge.on('disconnected', () => {
    connected = false;
    mainWindow?.webContents.send('connection-changed', false);
  });
}

app.whenReady().then(async () => {
  createWindow();
  setupIPC();
  connected = await bridge.connect();
  if (connected && mainWindow) {
    mainWindow.webContents.send('connection-changed', true);
  }
});

app.on('window-all-closed', () => {
  bridge.disconnect();
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (mainWindow === null) createWindow();
});
